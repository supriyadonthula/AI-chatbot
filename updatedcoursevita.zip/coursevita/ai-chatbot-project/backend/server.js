// Import required modules
const http = require('http');
const url = require('url');
const { GoogleGenerativeAI } = require("@google/generative-ai");
const mongoose = require('mongoose'); // Import mongoose
require('dotenv').config(); // Use environment variables for sensitive info

// Replace this with your actual MongoDB URI
const mongoURI = process.env.MONGO_URI || 'mongodb://localhost:27017/chatbotDB';

// Connect to MongoDB
mongoose.connect(mongoURI)
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("MongoDB connection error:", err));

// Define a schema and model for chat history
const chatSchema = new mongoose.Schema({
    userMessage: String,
    botResponse: String,
    timestamp: { type: Date, default: Date.now }
});
const Chat = mongoose.model('Chat', chatSchema);

// Initialize the Google Generative AI client with your API key
const genAI = new GoogleGenerativeAI(process.env.OPENAI_API_KEY); // Use environment variable for API key
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Set the server port
const port = 5000;

// Create the HTTP server
const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);

    // Allow CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Handle OPTIONS request for CORS preflight
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
    }

    // Handle GET request for chat history
    if (parsedUrl.pathname === '/chat-history' && req.method === 'GET') {
        Chat.find()
            .then(chats => {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(chats));
            })
            .catch(err => {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: "Failed to retrieve chat history" }));
            });

    // Handle POST request for sending a message
    } else if (parsedUrl.pathname === '/chat' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', async () => { // Mark this function as async
            try {
                console.log("Request Body:", body); // Log the raw request body
                const { message } = JSON.parse(body); // Parse the JSON message

                // Call the AI service to generate a response
                const result = await model.generateContent(message); // Use await in async function
                const botResponse = result.response.text();

                // Save to MongoDB
                const newChat = new Chat({ userMessage: message, botResponse });
                await newChat.save();

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ reply: botResponse }));
            } catch (error) {
                console.error("Error processing message:", error); // Log error details
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Invalid JSON format or AI service error' }));
            }
        });

    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
    }
});

// Start the server
server.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);

});
